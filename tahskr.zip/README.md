![status](https://img.shields.io/badge/status-beta-%23F4982B)

![Version](https://img.shields.io/github/package-json/v/dullage/tahskr.svg)
![Dependencies](https://img.shields.io/david/dullage/tahskr.svg)

# tahskr

A mobile responsive website and electron app to manage to-dos.

Also see [tahskr-server](https://github.com/Dullage/tahskr-server).
